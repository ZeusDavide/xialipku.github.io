---
# Documentation: https://sourcethemes.com/academic/docs/managing-content/

title: "R^2 Net Recurrent and Recursive Network for Sparse View CT Artifacts Removal"
authors:
- Tiancheng Shen*
- <b><u>Xia Li*</u></b>
- Zhisheng Zhong
- Jianlong Wu
- Zhouchen Lin
date: 2019-06-19T21:02:38+08:00
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: 2019-07-19T21:02:38+08:00
others: equal contribution

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["1"]

# Publication name and optional abbreviated publication name.
publication: "Medical Image Computing and Computer Assisted Interventions"
publication_short: "MICCAI"

abstract: "We propose a novel neural network architecture to reduce streak artifacts generated in sparse-view 2D Cone Beam Computed To-mography (CBCT) image reconstruction. This architecture decomposes the streak artifacts removal into multiple stages through the recurrent mechanism, which can fully utilize information in previous stages and guide the learning of later stages. In each recurrent stage, the key components of the architecture are computed recursively. The recursive mechanism is helpful to save parameters and enlarge the receptive field effiently with exponentially increased dilation of convolution. To verify its ectiveness, we conduct experiments on the AAPM CBCT dataset through 5-fold cross-validation. Our proposed method outperforms the state-of-the-art methods both quantitatively and qualitatively."

# Summary. An optional shortened abstract.
summary: "We propose a novel neural network architecture to reduce streak artifacts generated in sparse-view 2D Cone Beam Computed To-mography (CBCT) image reconstruction."

tags: []
categories: []
featured: true

# Custom links (optional).
#   Uncomment and edit lines below to show custom links.
# links:
# - name: Follow
#   url: https://twitter.com
#   icon_pack: fab
#   icon: twitter

url_pdf:
url_code:
url_dataset:
url_poster:
url_project:
url_slides:
url_source:
url_video:

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ""
  focal_point: ""
  preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: []

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
slides: ""
---
