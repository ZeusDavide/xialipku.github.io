---
# Documentation: https://sourcethemes.com/academic/docs/managing-content/

title: "Expectation Maximization Attention Networks for Semantic Segmentation"
authors:
- <b><u>Xia Li</u></b>
- Zhisheng Zhong
- Jianlong Wu
- Yibo Yang
- Zhouchen Lin
- Hong Liu
date: 2019-07-22T21:30:06+08:00
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: 2019-07-19T21:30:06+08:00
others: Oral 4.3%

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["1"]

# Publication name and optional abbreviated publication name.
publication: "International Conference in Computer Vision"
publication_short: "ICCV"

abstract: "Self-attention mechanism has been widely used for various tasks. It is designed to compute the representation of each position by a weighted sum of the features at all positions. Thus, it can capture long-range relations for computer vision tasks. However, it is computationally consuming. Since the attention maps are computed w.r.t all other positions. In this paper, we formulate the attention mechanism into an expectation-maximization manner and iteratively estimate a much more compact set of bases upon which the attention maps are computed. By a weighted summation upon these bases, the resulting representation is low-rank and deprecates noisy information from the input. The proposed Expectation-Maximization Attention (EMA) module is robust to the variance of input and is also friendly in memory and computation. Moreover, we set up the bases maintenance and normalization methods to stabilize its training procedure. We conduct extensive experiments on popular semantic segmentation benchmarks including PASCAL VOC, PASCAL Context, and COCO Stuff, on which we set new records."

# Summary. An optional shortened abstract.
summary: "We formulate the attention mechanism into an expectation-maximization manner and iteratively estimate a much more compact set of bases upon which the attention maps are computed."

tags: []
categories: []
featured: true

# Custom links (optional).
#   Uncomment and edit lines below to show custom links.
# links:
# - name: Follow
#   url: https://twitter.com
#   icon_pack: fab
#   icon: twitter

url_pdf: "http://openaccess.thecvf.com/content_ICCV_2019/papers/Li_Expectation-Maximization_Attention_Networks_for_Semantic_Segmentation_ICCV_2019_paper.pdf"
url_code: "https://github.com/XiaLiPKU/EMANet"
url_dataset:
url_poster:
url_project: "https://xialipku.github.io/EMANet/"
url_slides: "https://drive.google.com/file/d/1JjDWzOSavoS7LuZu_lWku245kDnwsF05/view?usp=sharing"
url_source:
url_video:

links:
- name: Zhihu
  url: "https://zhuanlan.zhihu.com/p/78018142"
- name: Survey
  url: "https://zhuanlan.zhihu.com/p/77834369"
- name: Leaderboard
  url: "http://host.robots.ox.ac.uk:8080/leaderboard/displaylb_main.php?challengeid=11&compid=6"

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ""
  focal_point: ""
  preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: []

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
slides: ""
---
