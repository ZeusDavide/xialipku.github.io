---
# Documentation: https://sourcethemes.com/academic/docs/managing-content/

title: "Recurrent Squeeze-and-Excitation Net for Single Image Deraining"
authors:
- <b><u>Xia Li</u></b>
- Jianlong Wu
- Zhouchen Lin
- Hong Liu
- Hongbin Zha
date: 2018-07-19T19:54:59+08:00
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: 2018-07-19T19:54:59+08:00

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["1"]

# Publication name and optional abbreviated publication name.
publication: "European Conference on Computer Vision"
publication_short: "ECCV"

abstract: "Rain streaks can severely degrade the visibility, which causesmany current computer vision algorithms fail to work. So it is necessaryto remove the rain from images. We propose a novel deep network ar-chitecture based on deep convolutional and recurrent neural networksfor single image deraining. As contextual information is very importantfor rain removal, we first adopt the dilated convolutional neural networkto acquire large receptive field. To better fit the rain removal task, wealso modify the network. In heavy rain, rain streaks have various direc-tions and shapes, which can be regarded as the accumulation of multiplerain streak layers. We assign different alpha-values to various rain streaklayers according to the intensity and transparency by incorporating thesqueeze-and-excitation block. Since rain streak layers overlap with eachother, it is not easy to remove the rain in one stage. So we further de-compose the rain removal into multiple stages. Recurrent neural networkis incorporated to preserve the useful information in previous stages andbenefit the rain removal in later stages. We conduct extensive experi-ments on both synthetic and real-world datasets. Our proposed methodoutperforms the state-of-the-art approaches under all evaluation metrics."

# Summary. An optional shortened abstract.
summary: "We propose a novel deep network architecture based on deep convolutional and recurrent neural networksfor single image deraining."

tags: []
categories: []
featured: true

# Custom links (optional).
#   Uncomment and edit lines below to show custom links.
# links:
# - name: Follow
#   url: https://twitter.com
#   icon_pack: fab
#   icon: twitter

url_pdf: "http://openaccess.thecvf.com/content_ECCV_2018/papers/Xia_Li_Recurrent_Squeeze-and-Excitation_Context_ECCV_2018_paper.pdf"
url_code: "https://github.com/XiaLiPKU/RESCAN"
url_dataset: "http://www.icst.pku.edu.cn/struct/Projects/joint_rain_removal.html"
url_poster:
url_project:
url_slides:
url_source:
url_video:
links:
- name: Report
  url: https://mp.weixin.qq.com/s/_tvOQPvybqmvLF19kHcbFg

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ""
  focal_point: ""
  preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: []

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
slides: ""
---
