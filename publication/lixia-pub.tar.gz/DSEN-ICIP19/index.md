---
# Documentation: https://sourcethemes.com/academic/docs/managing-content/

title: "Self Refining Deep Symmetry Enhanced Network for Rain Removal"
authors: 
- Hong Liu
- Hanrong Ye
- <b><u>Xia Li</u></b>
- Wei Shi
- Mengyuan Liu
- Qianru Sun
date: 2019-05-19T21:21:54+08:00
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: 2019-07-19T21:21:54+08:00

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["1"]

# Publication name and optional abbreviated publication name.
publication: "International Conference on Image Processing"
publication_short: "ICIP"

abstract: "Rain removal aims to remove the rain streaks on rain images. The state-of-the-art methods are mostly based on Con-volutional Neural Network (CNN). However, as CNN is notequivariant to object rotation, these methods are unsuitablefor dealing with the tilted rain streaks. To tackle this problem,we propose Deep Symmetry Enhanced Network (DSEN) thatis able to explicitly extract the rotation equivariant featuresfrom rain images. In addition, we design a self-refining mech-anism to remove the accumulated rain streaks in a coarse-to-fine manner. This mechanism reuses DSEN with a novel in-formation link which passes the gradient flow to the higherstages. Extensive experiments on both synthetic and real-world rain images show that our self-refining DSEN yieldsthe top performance."

# Summary. An optional shortened abstract.
summary: "We propose Deep Symmetry Enhanced Network (DSEN) thatis able to explicitly extract the rotation equivariant featuresfrom rain images."

tags: []
categories: []
featured: true

# Custom links (optional).
#   Uncomment and edit lines below to show custom links.
# links:
# - name: Follow
#   url: https://twitter.com
#   icon_pack: fab
#   icon: twitter

url_pdf: "https://arxiv.org/pdf/1811.04761.pdf"
url_code: "https://github.com/prismformore/SDSEN"
url_dataset:
url_poster:
url_project:
url_slides:
url_source:
url_video:

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ""
  focal_point: ""
  preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: []

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
slides: ""
---
